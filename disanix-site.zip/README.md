# DisaniX — Marketing Website

A premium single-page marketing site for **DisaniX**, a London-based technology & digital
consulting firm. Static HTML/CSS/JS — no build step, no dependencies, opens in any browser.

**Services:** Digital Transformation · SAP · Analytics · AI

## View it

Just open `index.html` in a browser. (Double-click it, or right-click → Open with.)
Everything is self-contained; the only network request is Google Fonts.

## Structure

```
index.html              # Page markup (semantic, accessible)
assets/css/styles.css   # Design system + all styling, light & dark themes
assets/js/main.js       # Reveal animations, count-ups, nav, theme, form
```

## Page sections

Content takes inspiration from large UK professional-services firms (Deloitte UK),
structured around *Who we are → What we do → Our thinking → Careers*:

Hero → Trusted-by → **What we do** (Digital Transformation, SAP, Analytics, AI) →
**Industries** (6 sectors) → Approach (4 steps) → Impact metrics → Selected work →
Testimonial → **Our thinking / Insights** (thought-leadership tiles) → Team →
**Careers** → Contact → Footer.

## Design system

- **Direction:** "Trust & Authority" — credible, corporate, metric-led, with an editorial
  layer inspired by McKinsey and BCG.
- **Type:** an editorial **serif display** face (Fraunces) for headlines, big statistics and the
  pull-quote — the McKinsey "Bower"-style authority move — over **Lexend** for the functional UI
  layer (nav, buttons, eyebrows, cards) and **Source Sans 3** for body copy.
- **Editorial touches:** a full-width *featured insight* banner (McKinsey "Featured Insights"),
  underline-wipe link interactions, hairline rules, and bold green-on-near-black contrast (BCG).
- **Brand:** black + green, after the DisaniX logo (wordmark with a green "X").
- **Colour:** near-black `#05070A` canvas, green core `#34D399`/`#22C55E`, and a green→cyan→blue
  gradient (`#34D399 → #22D3EE → #3B82F6`) drawn from the logo's wave lines. Full light & dark
  themes (toggle in the header; remembers your choice; respects OS preference on first visit).
- **Signature motif:** the flowing wave-line graphic from the logo, recreated in SVG behind the hero.
  The logo is rendered as live type — drop in your real logo file if you'd prefer the exact asset.

## Animations (elegant + performant)

- Scroll-reveal with staggered entrance (IntersectionObserver, transform/opacity only).
- Count-up statistics that run once when scrolled into view.
- Animated gradient mesh in the hero with subtle pointer parallax (desktop only).
- Hover micro-interactions on cards, buttons, nav and the client marquee.
- **All motion is disabled automatically when `prefers-reduced-motion` is set.**

## Responsive

Mobile-first, tested breakpoints at 375 / 620 / 860 / 1024 / 1440px, with a slide-down
mobile menu and no horizontal scroll.

## Placeholders to replace before launch

These are clearly fake and meant to be swapped:

- **Team names** — all show "Placeholder Name" with roles.
- **Testimonial** — "Placeholder Name", Helix Bank (fictional client).
- **Client logos** in the marquee (Northwind, Helix Bank, etc.) — fictional.
- **Metrics & case studies** — illustrative figures, not real engagements.
- **Contact details** — `hello@disanix.com`, `+44 20 7123 4567`, `1 Example Street, London EC2A 1AB`.
- **Company registration number** in the footer.

## Contact form

The form has full client-side validation and a success state, but is **not wired to a backend** —
on submit it simulates sending. To make it live, point the `submit` handler in `main.js` at your
email service / form endpoint (e.g. Formspree, a serverless function, or your CRM).
