/* =====================================================================
   Disanix — interaction layer
   Lightweight, dependency-free, accessibility-first.
   ===================================================================== */
(function () {
  "use strict";

  const prefersReducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  /* ---------------------------------------------------------------
     Year in footer
  --------------------------------------------------------------- */
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------------------------------------------------------------
     Theme toggle (persisted, respects system on first visit)
  --------------------------------------------------------------- */
  const root = document.documentElement;
  const toggle = document.getElementById("theme-toggle");
  const stored = localStorage.getItem("disanix-theme");

  if (stored) {
    root.setAttribute("data-theme", stored);
  } else if (window.matchMedia("(prefers-color-scheme: light)").matches) {
    root.setAttribute("data-theme", "light");
  }

  if (toggle) {
    toggle.addEventListener("click", function () {
      const next =
        root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", next);
      localStorage.setItem("disanix-theme", next);
    });
  }

  /* ---------------------------------------------------------------
     Header scroll state
  --------------------------------------------------------------- */
  const header = document.querySelector(".site-header");
  const onScroll = function () {
    if (window.scrollY > 12) header.classList.add("scrolled");
    else header.classList.remove("scrolled");
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------------------------------------------------------------
     Mobile navigation
  --------------------------------------------------------------- */
  const navToggle = document.getElementById("nav-toggle");
  const navLinks = document.getElementById("nav-links");

  if (navToggle && navLinks) {
    const closeMenu = function () {
      navLinks.classList.remove("open");
      navToggle.setAttribute("aria-expanded", "false");
      navToggle.setAttribute("aria-label", "Open menu");
    };
    navToggle.addEventListener("click", function () {
      const open = navLinks.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(open));
      navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    });
    navLinks.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", closeMenu);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeMenu();
    });
  }

  /* ---------------------------------------------------------------
     Scroll-reveal (IntersectionObserver)
     Sets a per-element stagger delay then reveals on enter.
  --------------------------------------------------------------- */
  const revealEls = document.querySelectorAll("[data-reveal]");

  revealEls.forEach(function (el) {
    const delay = el.getAttribute("data-reveal-delay");
    if (delay) el.style.setProperty("--reveal-delay", delay);
  });

  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    revealEls.forEach(function (el) {
      el.classList.add("in");
    });
  } else {
    const revealObserver = new IntersectionObserver(
      function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" }
    );
    revealEls.forEach(function (el) {
      revealObserver.observe(el);
    });
  }

  /* ---------------------------------------------------------------
     Count-up numbers (runs once when in view)
  --------------------------------------------------------------- */
  const counters = document.querySelectorAll("[data-count]");

  const formatNumber = function (value, decimals) {
    return value.toLocaleString("en-GB", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
  };

  const runCount = function (el) {
    const target = parseFloat(el.getAttribute("data-count"));
    const decimals = parseInt(el.getAttribute("data-decimals") || "0", 10);
    const suffix = el.getAttribute("data-suffix") || "";

    if (prefersReducedMotion) {
      el.textContent = formatNumber(target, decimals) + suffix;
      return;
    }

    const duration = 1500;
    const start = performance.now();
    const ease = function (t) {
      return 1 - Math.pow(1 - t, 3);
    };

    const tick = function (now) {
      const progress = Math.min((now - start) / duration, 1);
      const current = target * ease(progress);
      el.textContent = formatNumber(current, decimals) + suffix;
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = formatNumber(target, decimals) + suffix;
    };
    requestAnimationFrame(tick);
  };

  if (!("IntersectionObserver" in window)) {
    counters.forEach(runCount);
  } else {
    const countObserver = new IntersectionObserver(
      function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            runCount(entry.target);
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.6 }
    );
    counters.forEach(function (el) {
      countObserver.observe(el);
    });
  }

  /* ---------------------------------------------------------------
     Active nav link on scroll (scroll-spy)
  --------------------------------------------------------------- */
  const sections = document.querySelectorAll("main section[id]");
  const linkFor = {};
  document.querySelectorAll(".nav__links a").forEach(function (a) {
    const id = a.getAttribute("href").replace("#", "");
    linkFor[id] = a;
  });

  if ("IntersectionObserver" in window && sections.length) {
    const spy = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          const link = linkFor[entry.target.id];
          if (!link) return;
          if (entry.isIntersecting) {
            Object.values(linkFor).forEach(function (l) {
              l.classList.remove("active");
            });
            link.classList.add("active");
          }
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    sections.forEach(function (s) {
      spy.observe(s);
    });
  }

  /* ---------------------------------------------------------------
     Subtle pointer parallax on hero orbs (desktop, motion-safe)
  --------------------------------------------------------------- */
  if (!prefersReducedMotion && window.matchMedia("(pointer: fine)").matches) {
    const orbs = document.querySelectorAll(".orb");
    let raf = null;
    window.addEventListener(
      "pointermove",
      function (e) {
        if (raf) return;
        raf = requestAnimationFrame(function () {
          const cx = (e.clientX / window.innerWidth - 0.5) * 2;
          const cy = (e.clientY / window.innerHeight - 0.5) * 2;
          orbs.forEach(function (orb, i) {
            const depth = (i + 1) * 8;
            orb.style.translate = cx * depth + "px " + cy * depth + "px";
          });
          raf = null;
        });
      },
      { passive: true }
    );
  }

  /* ---------------------------------------------------------------
     Contact form — accessible inline validation + simulated submit
  --------------------------------------------------------------- */
  const form = document.getElementById("contact-form");
  if (form) {
    const status = document.getElementById("form-status");
    const submitBtn = document.getElementById("submit-btn");
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    const fields = {
      name: { el: form.name, msg: "Please enter your name." },
      email: {
        el: form.email,
        msg: "Please enter a valid email address.",
        test: function (v) {
          return emailRe.test(v);
        },
      },
      message: { el: form.message, msg: "Please tell us how we can help." },
    };

    const setError = function (key, show) {
      const f = fields[key];
      const wrap = f.el.closest(".field");
      const errEl = form.querySelector('[data-error-for="' + key + '"]');
      wrap.classList.toggle("invalid", show);
      f.el.setAttribute("aria-invalid", show ? "true" : "false");
      errEl.textContent = show ? f.msg : "";
    };

    const validate = function (key) {
      const f = fields[key];
      const v = f.el.value.trim();
      const ok = f.test ? f.test(v) : v.length > 0;
      setError(key, !ok);
      return ok;
    };

    // Validate on blur (not on keystroke)
    Object.keys(fields).forEach(function (key) {
      fields[key].el.addEventListener("blur", function () {
        validate(key);
      });
      fields[key].el.addEventListener("input", function () {
        if (fields[key].el.closest(".field").classList.contains("invalid")) {
          validate(key);
        }
      });
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      status.textContent = "";
      status.className = "form__status";

      let firstInvalid = null;
      let allOk = true;
      Object.keys(fields).forEach(function (key) {
        const ok = validate(key);
        if (!ok && !firstInvalid) firstInvalid = fields[key].el;
        if (!ok) allOk = false;
      });

      if (!allOk) {
        if (firstInvalid) firstInvalid.focus();
        status.textContent = "Please fix the highlighted fields.";
        status.classList.add("error");
        return;
      }

      // Simulated async submit (no backend wired yet)
      submitBtn.disabled = true;
      submitBtn.querySelector(".btn__label").textContent = "Sending…";

      setTimeout(function () {
        submitBtn.disabled = false;
        submitBtn.querySelector(".btn__label").textContent = "Send message";
        form.reset();
        status.textContent =
          "Thank you — your message has been received. We'll reply within one working day.";
        status.classList.add("success");
      }, 900);
    });
  }
})();
